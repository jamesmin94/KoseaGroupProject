function move() {
    location.href = 'http://www.naver.com'
}
function moveinsta(){
    location.href ='https://www.instagram.com/?hl=ko'
    
}
function movefacebook(){
    location.href='https://ko-kr.facebook.com/'
}
function moveyoutube(){
    location.href='https://www.youtube.com/'
}
//var i3 = document.getElementById("i3").style.visibility="visible"; 
function openNav() {
    document.getElementById("sideNavid").style.width = "250px";
}
function closeNav() {
    document.getElementById("sideNavid").style.width = 0;
}